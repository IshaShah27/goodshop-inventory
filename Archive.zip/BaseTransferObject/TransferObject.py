
class TransferObject:

    def __init__(self):
        pass
