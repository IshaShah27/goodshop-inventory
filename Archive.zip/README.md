# goodshop-inventory
E6156 Cloud Computing testing
